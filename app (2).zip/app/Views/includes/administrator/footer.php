<footer class="main-footer">
        <div class="footer-left">
        <p>© 2021 <a target="_blank" href="https://www.emaskita.id">EmasKITA</a> All Rights Reserved</p>
        </div>
        <div class="footer-right">
        </div>
</footer>